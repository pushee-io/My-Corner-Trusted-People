# Changelog

## 2026-07-24

- Added Day 2B verified-neighborhood database migration.
- Added private identity, residential address, location evidence, residence challenge, membership, community post, audience, and profile-location preference tables.
- Added server-side functions for test identity assurance, test postcard challenge creation, postcard verification, PostGIS neighborhood assignment, verified membership checks, and private neighborhood post creation.
- Added RLS and column-level grants protecting legal names, exact addresses, GhanaPost GPS, exact coordinates, raw location evidence, postcard hashes, and audit events.
- Added Day 2B RLS smoke test for verified-only neighborhood feed access.
- Updated database CI runner to apply all migrations and run both Module 1 and Day 2B smoke tests.
