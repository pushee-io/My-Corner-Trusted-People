# Day 2B Database Model

Date added: 2026-07-24

## Scope

This database-first slice supports verified resident onboarding, server-controlled neighborhood assignment, and private neighborhood feed access. It does not implement the mobile screens yet.

## Migration

`supabase/migrations/20260724042000_day2b_verified_neighborhood_access.sql`

## New Data Areas

- `private_identity_profiles`: legal names and test-mode identity assurance state, separate from public display name.
- `identity_assurance_events`: auditable identity-assurance events with no Ghana Card image collection.
- `private_addresses`: Ghana-compatible residential address components, GhanaPost GPS, normalized point, user-confirmed point, and assigned neighborhood.
- `address_normalization_events`: address-provider abstraction events.
- `location_verification_attempts`: foreground location-consistency evidence, insert-only for ordinary clients.
- `residence_challenges`: salted, hashed test postcard codes with expiration, attempt counts, single-use consumption, and rate limiting.
- `neighborhood_boundaries`: PostGIS boundaries for server-side point-in-polygon assignment.
- `neighborhood_clusters` and `neighborhood_cluster_members`: future immediate-cluster audience support.
- Extended `neighborhood_memberships`: verification status, method, timestamps, expiration, and re-verification fields.
- `membership_events`: auditable membership status history.
- `community_posts` and `community_post_audiences`: ordinary private neighborhood posts and explicit audience model.
- `profile_location_preferences`: masked public profile and map-location preferences.
- `public_community_profiles`: safe public profile view without exact residential data.

## Server-Controlled Functions

- `complete_test_identity_assurance(legal_given_name, legal_family_name)`: creates/updates the private identity record, generates the public display format, and records audit evidence that no Ghana Card image was collected.
- `create_test_residence_challenge(address_id, test_code)`: creates a single-use salted test postcard challenge for the caller's own current address and rate-limits challenge creation.
- `verify_test_residence_challenge(challenge_id, submitted_code)`: consumes a valid challenge, assigns the neighborhood using PostGIS boundaries, verifies membership, and writes membership/audit events.
- `create_private_neighborhood_post(title, body)`: creates a private post only for users with an active verified primary neighborhood membership.
- `has_verified_neighborhood_membership(neighborhood_id)`: shared RLS predicate for private feed access.

## RLS Guarantees

- Unverified users cannot read or create private neighborhood posts.
- Verified users can read ordinary posts only in their verified neighborhood.
- Cross-neighborhood users cannot read ordinary local posts.
- Clients cannot grant themselves a verified membership or change their verified neighborhood identifier.
- Ordinary users cannot read another person's legal identity or private address.
- Ordinary users cannot read GhanaPost GPS, exact coordinates, raw location-check details, postcard-code hashes, or audit events.
- Address changes move verified memberships into `requires_reverification`.

## Verification

Run:

```bash
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/postgres bash scripts/db-smoke-test.sh
```

The script applies all migrations, loads seed data, runs Module 1 RLS smoke tests, and runs `supabase/tests/day2b_verified_neighborhood_access.sql`.
