# Database Smoke Test

Date added: 2026-07-24

## Purpose

This smoke test removes the caveat that SQL/RLS changes were only written down. It verifies the migrations against a real PostgreSQL database with PostGIS support and tests the core requester/provider access rules plus Day 2B verified-neighborhood feed isolation.

## Command

```bash
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/postgres bash scripts/db-smoke-test.sh
```

The target database must have PostGIS available because the migration creates `provider_service_areas.approximate_area` as `geography(polygon, 4326)`.

## What It Verifies

- Migration SQL applies with Supabase-style `anon`, `authenticated`, and `auth.uid()` support.
- Seed data creates exactly 12 fictional providers.
- Every seeded provider has at least four trust signals.
- A requester can read active providers and create their own job request.
- A requester can attach a request photo.
- A requester cannot accept a request as if they were the provider.
- The assigned provider can read the request general area and update status to `Viewed`.
- The assigned provider cannot read `exact_address_private` through normal client grants.
- The assigned provider can create an `Accepted` provider response.
- The assigned provider cannot change the requester on the request.
- An unassigned provider cannot read or update another provider's request.

## CI

`.github/workflows/database-ci.yml` runs the same test against `postgis/postgis:16-3.4`.

The Day 2B smoke test verifies:

- Test-mode identity assurance creates a private legal identity record and masked public display name.
- Ordinary client grants cannot read legal name columns.
- Private residential addresses support Ghana-compatible fields, GhanaPost GPS, normalized point, and user-confirmed point.
- Ordinary client grants cannot read GhanaPost GPS, exact coordinates, raw location-check data, or postcard-code hashes.
- A test postcard challenge can be created for the caller's own current address.
- A valid test postcard code assigns the correct neighborhood through PostGIS boundaries.
- Consumed postcard challenges cannot be reused.
- Verified same-neighborhood members can read ordinary private posts.
- Verified members from another neighborhood cannot read ordinary local posts.
- Unverified users cannot read or create private neighborhood posts through direct table access or the server function.
- Users cannot alter their verified neighborhood identifier.
- Address changes place verified membership into `requires_reverification`.
- Ordinary moderator role cannot read identity evidence or private addresses without an explicit policy.
- Membership verification and re-verification changes create audit events.

## Local Environment Note

This ChatGPT workspace does not currently include `psql`, Docker, or Supabase CLI. The apt and npm registries are blocked by the environment, so the real database run is wired for CI and any developer machine with PostgreSQL/PostGIS access.
